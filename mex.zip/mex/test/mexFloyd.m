% function [dist, path] = mexFloyd(G)
% G is distance matrix, with n vertex
% dist is n*n double matrix
% path is n*n cell matrix